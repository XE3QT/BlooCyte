import React, { useState } from "react";
import { Container, Input, VStack, Textarea, Button, FormControl, FormLabel } from "@chakra-ui/react";

const ContactForm = () => {
  const [inputs, setInputs] = useState({
    name: "",
    companyName: "",
    email: "",
    country: "",
    city: "",
    message: "",
  });

  const handleChange = (e) => {
    const { id, value } = e.target;
    setInputs({
      ...inputs,
      [id]: value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const mailtoLink = `mailto:cytebloo@gmail.com?subject=Contact from ${inputs.name}&body=Company Name: ${inputs.companyName}%0AEmail: ${inputs.email}%0ACountry: ${inputs.country}%0ACity: ${inputs.city}%0AMessage: ${inputs.message}`;
    window.location.href = mailtoLink;
  };

  return (
    <Container maxW="container.md" py={10}>
      <form onSubmit={handleSubmit}>
        <VStack spacing={5}>
          <FormControl id="name">
            <FormLabel>Name</FormLabel>
            <Input type="text" placeholder="Your Name" value={inputs.name} onChange={handleChange} />
          </FormControl>
          <FormControl id="companyName">
            <FormLabel>Company Name</FormLabel>
            <Input type="text" placeholder="Your Company Name" value={inputs.companyName} onChange={handleChange} />
          </FormControl>
          <FormControl id="email">
            <FormLabel>Email Address</FormLabel>
            <Input type="email" placeholder="Your Email" value={inputs.email} onChange={handleChange} />
          </FormControl>
          <FormControl id="country">
            <FormLabel>Country</FormLabel>
            <Input type="text" placeholder="Your Country" value={inputs.country} onChange={handleChange} />
          </FormControl>
          <FormControl id="city">
            <FormLabel>City</FormLabel>
            <Input type="text" placeholder="Your City" value={inputs.city} onChange={handleChange} />
          </FormControl>
          <FormControl id="message">
            <FormLabel>Message</FormLabel>
            <Textarea placeholder="Your Message" value={inputs.message} onChange={handleChange} />
          </FormControl>
          <Button type="submit" colorScheme="blue">
            Submit
          </Button>
        </VStack>
      </form>
    </Container>
  );
};

export default ContactForm;
