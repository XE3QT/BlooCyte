import React from "react";
import { Box, Container, Flex, Heading, SimpleGrid, VStack, useColorModeValue, ScaleFade, Button, Image, Text } from "@chakra-ui/react"; // Import all necessary components from Chakra UI only once
import { FaPaintBrush, FaCode, FaMobileAlt, FaRocket } from "react-icons/fa"; // Import icons only once

const ServiceCard = ({ title, icon, children }) => {
  const bg = useColorModeValue("white", "gray.800");
  const color = useColorModeValue("gray.600", "white");

  return (
    <ScaleFade initialScale={0.9} in={true}>
      <VStack bg={bg} boxShadow="md" padding={5} rounded="lg" align="start" spacing={3} _hover={{ transform: "scale(1.05)", transition: "transform .3s ease-in-out" }}>
        <Flex w={12} h={12} align="center" justify="center" color="white" rounded="full" bg="gray.500">
          {icon}
        </Flex>
        <Heading as="h3" size="md" fontWeight="bold">
          {title}
        </Heading>
        <Text color={color}>{children}</Text>
      </VStack>
    </ScaleFade>
  );
};

const Index = () => {
  return (
    <Box bg="linear-gradient(180deg, white 0%, black 100%)" color="white" minH="100vh">
      <Container maxW="container.xl">
        <Heading as="h2" size="3xl" textAlign="center" fontWeight="bold" mb={6} mt={6} mb={4} style={{ textShadow: "2px 2px 12px rgba(0, 0, 255, 0.3)" }}>
          BlooCyte
        </Heading>

        <Flex align="center" justify="center" direction="column" mb={20} w="full">
          <Flex gap={2}>
            <Button as="a" href="https://kgosis-superb-site.webflow.io" colorScheme="gray">
              About Me
            </Button>
            <Button as="a" href="/contact">
              Let's Talk
            </Button>
          </Flex>
          <Heading as="h1" size="3xl" mb={3} textAlign="center" style={{ textShadow: "2px 2px 12px rgba(0, 0, 0, 0.6)", textAlign: "center" }}>
            Premium Website Solutions
          </Heading>
          <Text fontSize="lg" color="gray.500" textAlign="center">
            Crafting elegant and professional web experiences
          </Text>
          <iframe src="https://lottie.host/embed/655f580b-68d7-42f4-ac10-135998cd6ce6/KYKAAv81Ql.json" style={{ width: "300px", height: "300px", border: "none", marginBottom: "1.5rem" }} loop autoPlay></iframe>
          <Text textAlign="center" fontFamily="Courier New">
            Hi, my name is Bloo. Welcome to my friend's website. His name is Kgosi and he makes the coolest websites ever! I hear some of his friends get a whole lot more clients after he builds websites for them. Crazy part it, he does it almost for free! I know right!? If it was up to me, I would have done it a for a gajillion battery cells!! Anyway, send him a message if you're interested in having your own cool website. Tell him Bloo sent you.
          </Text>
        </Flex>

        <SimpleGrid columns={{ base: 1, md: 2, lg: 4 }} spacing={10}>
          <ServiceCard title="Design" icon={<FaPaintBrush fontSize="1.5em" />}>
            Unique and visually stunning designs tailored to your brand's aesthetics.
          </ServiceCard>

          <ServiceCard title="Development" icon={<FaCode fontSize="1.5em" />}>
            Clean, efficient, and robust code to ensure a seamless user experience.
          </ServiceCard>

          <ServiceCard title="Responsive" icon={<FaMobileAlt fontSize="1.5em" />}>
            Mobile-ready websites that look great on any device and screen size.
          </ServiceCard>

          <ServiceCard title="Launch" icon={<FaRocket fontSize="1.5em" />}>
            End-to-end service from development to deployment for a smooth launch.
          </ServiceCard>
        </SimpleGrid>
      </Container>
    </Box>
  );
};

export default Index;
