#!/bin/bash
npm install
npm run dev